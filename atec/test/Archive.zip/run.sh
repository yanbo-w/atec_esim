#!/bin/bash
python atec_sim_0730.py $1 $2